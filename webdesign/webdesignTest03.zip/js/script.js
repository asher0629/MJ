$(function(){
    $(".main_menu").mouseover(function(){
        $(".sub_menu").stop().slideDown();
        $(".sub_menu").css("display","flex");
    });
    $(".menu").mouseleave(function(){
        $(this).children(".sub_menu").stop().slideUp();
    })
});

setInterval(function(){
    $(".slide ul").delay("2500");
    $(".slide ul").fadeOut().animate({marginTop: "-300px"});
    $(".slide ul").fadeIn();
    $(".slide ul").delay("2500");
    $(".slide ul").fadeOut().animate({marginTop: "-600px"});
    $(".slide ul").fadeIn("250")
    $(".slide ul").delay("2500");
    $(".slide ul").fadeOut().animate({marginTop: "0"});
    $(".slide ul").fadeIn("250")
});